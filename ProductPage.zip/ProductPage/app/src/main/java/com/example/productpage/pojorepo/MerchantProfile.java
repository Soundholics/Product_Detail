package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class MerchantProfile{

	@SerializedName("password")
	private String password;

	@SerializedName("name")
	private String name;

	@SerializedName("gstno")
	private String gstno;

	@SerializedName("rating")
	private double rating;

	@SerializedName("emailId")
	private String emailId;

	public String getPassword(){
		return password;
	}

	public String getName(){
		return name;
	}

	public String getGstno(){
		return gstno;
	}

	public double getRating(){
		return rating;
	}

	public String getEmailId(){
		return emailId;
	}
}