package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class MerchantData{

	@SerializedName("productId")
	private String productId;

	@SerializedName("merchantId")
	private String merchantId;

	@SerializedName("merchantPrice")
	private double merchantPrice;

	@SerializedName("merchantStock")
	private int merchantStock;

	public String getProductId(){
		return productId;
	}

	public String getMerchantId(){
		return merchantId;
	}

	public double getMerchantPrice(){
		return merchantPrice;
	}

	public int getMerchantStock(){
		return merchantStock;
	}
}