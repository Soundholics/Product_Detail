package com.example.productpage;

public class MerchantAvailable {

    private String merchantId;
    private String merchantName;
    private String merchantRating;
    private String merchantPrice;

    public MerchantAvailable(String merchantId, String merchantName, String merchantRating, String merchantPrice) {
        this.merchantId = merchantId;
        this.merchantName = merchantName;
        this.merchantRating = merchantRating;
        this.merchantPrice = merchantPrice;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantRating() {
        return merchantRating;
    }

    public void setMerchantRating(String merchantRating) {
        this.merchantRating = merchantRating;
    }

    public String getMerchantPrice() {
        return merchantPrice;
    }

    public void setMerchantPrice(String merchantPrice) {
        this.merchantPrice = merchantPrice;
    }
}
