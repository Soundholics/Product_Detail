package com.example.productpage.model;

public class ReviewData {



    private String customerName;
    private String customerRating;
    private String customerReview;

    public ReviewData( String customerName, String customerRating, String customerReview) {

        this.customerName = customerName;
        this.customerRating = customerRating;
        this.customerReview = customerReview;
    }





    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerRating() {
        return customerRating;
    }

    public void setCustomerRating(String customerRating) {
        this.customerRating = customerRating;
    }

    public String getCustomerReview() {
        return customerReview;
    }

    public void setCustomerReview(String customerReview) {
        this.customerReview = customerReview;
    }
}
