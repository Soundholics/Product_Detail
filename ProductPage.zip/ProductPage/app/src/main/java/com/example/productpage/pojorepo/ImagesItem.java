package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class ImagesItem{

	@SerializedName("imageUrl")
	private String imageUrl;

	public String getImageUrl(){
		return imageUrl;
	}
}