package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class RateItem{

	@SerializedName("review")
	private String review;

	@SerializedName("rating")
	private double rating;

	@SerializedName("customerId")
	private String customerId;

	public String getReview(){
		return review;
	}

	public double getRating(){
		return rating;
	}

	public String getCustomerId(){
		return customerId;
	}
}