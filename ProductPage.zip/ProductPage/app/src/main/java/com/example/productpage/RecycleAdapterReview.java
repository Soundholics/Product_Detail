package com.example.productpage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleAdapterReview extends RecyclerView.Adapter<RecycleAdapterReview.ViewHolder>{


    private final ProductDetailActivity productDetailActivity;
    private final List<ReviewData> reviewDataList;

    public RecycleAdapterReview(ProductDetailActivity productDetailActivity, List<ReviewData> reviewDataList) {
        this.productDetailActivity = productDetailActivity;
        this.reviewDataList = reviewDataList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_review_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        ReviewData userData = reviewDataList.get(position);
        holder.tvCustomerName.setText(userData.getCustomerName());
        holder.tvCustomerRating.setText(userData.getCustomerRating() + " ⭐️");
        holder.tvCustomerReview.setText(userData.getCustomerReview());
        holder.rootView.setOnClickListener((view -> productDetailActivity.onReviewClick(userData)));

    }

    @Override
    public int getItemCount() {
        return reviewDataList.size();
    }
    public interface CustomerReview
    {
        public void onReviewClick(ReviewData reviewData);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        private final TextView tvCustomerName;
        private final TextView tvCustomerRating;
        private final View rootView;
        private  final TextView tvCustomerReview;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.rootView = view;
            this.tvCustomerName = view.findViewById(R.id.customer_name_pd);
            this.tvCustomerRating = view.findViewById(R.id.customer_rating_pd);
            this.tvCustomerReview = view.findViewById(R.id.customer_review_pd);
        }
    }
}
