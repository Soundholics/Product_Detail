package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class CartAdd{

	@SerializedName("productId")
	private String productId;

	@SerializedName("merchantId")
	private String merchantId;

	@SerializedName("qty")
	private int qty;

	public String getProductId(){
		return productId;
	}

	public String getMerchantId(){
		return merchantId;
	}

	public int getQty(){
		return qty;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}
}