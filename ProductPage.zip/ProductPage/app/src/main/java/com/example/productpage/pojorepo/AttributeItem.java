package com.example.productpage.pojorepo;

import com.google.gson.annotations.SerializedName;

public class AttributeItem{

	@SerializedName("getAttributeValue")
	private String getAttributeValue;

	@SerializedName("attributeKey")
	private String attributeKey;

	public String getGetAttributeValue(){
		return getAttributeValue;
	}

	public String getAttributeKey(){
		return attributeKey;
	}
}