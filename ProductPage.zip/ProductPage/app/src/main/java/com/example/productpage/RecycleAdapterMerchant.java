package com.example.productpage;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecycleAdapterMerchant extends RecyclerView.Adapter<RecycleAdapterMerchant.ViewHolder> {

    private final ProductDetailActivity productDetailActivity;
    private final List<MerchantAvailable> merchantAvailableList;

    public RecycleAdapterMerchant(ProductDetailActivity productDetailActivity, List<MerchantAvailable> merchantAvailableList) {
        this.productDetailActivity = productDetailActivity;
        this.merchantAvailableList = merchantAvailableList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.merchant_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MerchantAvailable userData = merchantAvailableList.get(position);
        holder.tvMerchantName.setText(userData.getMerchantName());
        holder.tvMerchantPrice.setText("$" +userData.getMerchantPrice());
        holder.tvMerchantRating.setText("Rating "+userData.getMerchantRating() + " ⭐️");
        holder.rootView.setOnClickListener((view -> productDetailActivity.onMerchantClick(userData)));
    }

    public interface MerchantData
    {
        void onMerchantClick(MerchantAvailable merchantAvailable);
    }

    @Override
    public int getItemCount() {
        return merchantAvailableList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder
    {
        private final TextView tvMerchantName;
        private final TextView tvMerchantRating;
        private final View rootView;
        private  final TextView tvMerchantPrice;

        public ViewHolder(@NonNull View view) {
            super(view);
            this.rootView = view;
            this.tvMerchantName = view.findViewById(R.id.merchant_name_pd);
            this.tvMerchantPrice = view.findViewById(R.id.merchant_price_pd);
            this.tvMerchantRating = view.findViewById(R.id.merchant_rating_pd);
        }
    }
}
