package com.example.productpage.pojorepo;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class ProductData{

	@SerializedName("images")
	private List<ImagesItem> images;

	@SerializedName("productId")
	private String productId;

	@SerializedName("attribute")
	private List<AttributeItem> attribute;

	@SerializedName("category")
	private String category;

	@SerializedName("productName")
	private String productName;

	public List<ImagesItem> getImages(){
		return images;
	}

	public String getProductId(){
		return productId;
	}

	public List<AttributeItem> getAttribute(){
		return attribute;
	}

	public String getCategory(){
		return category;
	}

	public String getProductName(){
		return productName;
	}
}