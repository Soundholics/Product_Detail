package com.example.productpage.nwbuilder;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitBuilderProduct {

    private static Retrofit instance;

    private RetrofitBuilderProduct() {
    }

    public static Retrofit getInstance()
    {
        if(instance == null)
        {
            synchronized (RetrofitBuilderProduct.class){
                if(instance == null)
                {
                    instance = new Retrofit.Builder()
                            .baseUrl("https://jsonplaceholder.typicode.com/")
                            .addConverterFactory(GsonConverterFactory.create())
                            .client(new OkHttpClient()).build();
                }
            }
        }
        return instance;
    }
}
