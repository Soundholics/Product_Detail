package com.example.productpage;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProductDetailActivity extends AppCompatActivity implements RecycleAdapterMerchant.MerchantData, RecycleAdapterReview.CustomerReview  {

    CarouselView carouselView;
    int[] sampleImages = {R.drawable.image_1, R.drawable.image_2, R.drawable.image_3, R.drawable.image_4, R.drawable.image_5};


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productdetail);
        List<MerchantAvailable> merchantAvailableList = new ArrayList<>();
        List<ReviewData> reviewDataList = new ArrayList<>();
        populateMerchant(merchantAvailableList);
        populateReview(reviewDataList);

         double sumRating =0;
       // merchantAvailableList.sort((o1, o2) -> o1.getMerchantPrice().compareTo(o2.getMerchantPrice()));
        Collections.sort(merchantAvailableList, (o1, o2) -> Integer.valueOf(o1.getMerchantPrice())-Integer.valueOf(o2.getMerchantPrice()));
        TextView tvDefaultPrice =findViewById(R.id.tv_price_pd);
        TextView tvDefaultName = findViewById(R.id.tv_seller_name);
        tvDefaultPrice.setText("$"+merchantAvailableList.get(0).getMerchantPrice().toString());
        tvDefaultName.setText("Seller Name:" +merchantAvailableList.get(0).getMerchantName().toString());
        for (ReviewData m:reviewDataList
             ) {
            sumRating = sumRating + Double.valueOf(m.getCustomerRating());
        }
        double avgRating = sumRating/reviewDataList.size();
        TextView textView =findViewById(R.id.avg_rating_pd);
        textView.setText(String.valueOf((int)avgRating)+" ⭐️");//api implementation


        carouselView = findViewById(R.id.carouselView_pd);
        carouselView.setPageCount(sampleImages.length);
        carouselView.setImageListener(imageListener);



        RecyclerView recyclerView = findViewById(R.id.recycler_merchant_pd);
        RecycleAdapterMerchant recycleAdapterMerchant = new RecycleAdapterMerchant( ProductDetailActivity.this,merchantAvailableList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recycleAdapterMerchant);

        RecyclerView recyclerView1 = findViewById(R.id.recycler_reviews_pd);
        RecycleAdapterReview recycleAdapterReview = new RecycleAdapterReview( ProductDetailActivity.this,reviewDataList);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        recyclerView1.setAdapter(recycleAdapterReview);



        findViewById(R.id.add_to_cart_pd).setOnClickListener(view ->
        {
            //sent to cart object with details
            Toast.makeText(getApplicationContext(),tvDefaultName.getText(),Toast.LENGTH_SHORT).show();
        });


    }

    @Override
    public void onMerchantClick(MerchantAvailable merchantAvailable) {
        Toast.makeText(this,merchantAvailable.getMerchantId(),Toast.LENGTH_SHORT).show();
        TextView textView =findViewById(R.id.tv_price_pd);
        TextView textView1 = findViewById(R.id.tv_seller_name);
        textView.setText("$"+merchantAvailable.getMerchantPrice().toString());
        textView1.setText("Seller Name: "+merchantAvailable.getMerchantName());

    }

    @Override
    public void onReviewClick(ReviewData reviewData) {
        Toast.makeText(this,reviewData.getCustomerId(),Toast.LENGTH_SHORT).show();
    }

    ImageListener imageListener = (position, imageView) -> imageView.setImageResource(sampleImages[position]);
    public void imageClick(View view)
    {
        Log.i("TESTER", "imageClick:hi ");
    }

    public void populateMerchant(List<MerchantAvailable> merchantAvailables)
    {
        merchantAvailables.add(new MerchantAvailable("sdfds","Raja","4.5","200"));
        merchantAvailables.add(new MerchantAvailable("fsf","Abhinav","5","250"));
        merchantAvailables.add(new MerchantAvailable("dsf","Aaakash","4.5","3000"));
        merchantAvailables.add(new MerchantAvailable("sd","SHwetha","5","180"));
        merchantAvailables.add(new MerchantAvailable("dsgsd","Anirudh","4","20"));
    }
    public void populateReview(List<ReviewData> reviewData)
    {

        reviewData.add(new ReviewData("gdsg","Shubham","4.5","It is very Nice and good to use"));
        reviewData.add(new ReviewData("gdsg","Harish","4","Best in Range"));
        reviewData.add(new ReviewData("gdsg","Manav","3","Okay product"));
        reviewData.add(new ReviewData("gdsg","Rajat","5","You cant get a better offer so go grab it up"));
        reviewData.add(new ReviewData("gdsg","Girish","4.5","Makes me Happy ;)"));
        reviewData.add(new ReviewData("gdsg","Sonu","4","I wouldnt really care to rate but after using this for few days i really got some chiil these are reaaly Good in this raneg. "));


    }
}