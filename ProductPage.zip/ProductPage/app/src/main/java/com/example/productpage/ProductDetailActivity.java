package com.example.productpage;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.productpage.adapters.RecycleAdapterMerchant;
import com.example.productpage.adapters.RecycleAdapterReview;
import com.example.productpage.model.MerchantAvailable;
import com.example.productpage.model.ReviewData;
import com.example.productpage.network.IPostApi;
import com.example.productpage.nwbuilder.RetrofitBuilderProduct;
import com.example.productpage.pojorepo.AttributeItem;
import com.example.productpage.pojorepo.CartAdd;
import com.example.productpage.pojorepo.MerchantData;
import com.example.productpage.pojorepo.ProductData;
import com.example.productpage.pojorepo.RateItem;
import com.example.productpage.pojorepo.Ratings;
import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ProductDetailActivity extends AppCompatActivity implements RecycleAdapterMerchant.MerchantData, RecycleAdapterReview.CustomerReview  {

    CarouselView carouselView;
    int[] sampleImages = {R.drawable.image_1, R.drawable.image_2, R.drawable.image_3, R.drawable.image_4, R.drawable.image_5};
    String productName;
    int stocking;
    List<AttributeItem> productUsp;
    List<MerchantAvailable> merchantAvailableList = new ArrayList<>();
    List<ReviewData> reviewDataList = new ArrayList<>();
    double avgRating;


    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productdetail);
        //recieve product id via intent
        String productID = getIntent().getStringExtra("id");


        ///Call Apis on product id and check for stock
          //initApiReq(productID);



        TextView tvDefaultPrice =findViewById(R.id.tv_price_pd);
        TextView tvDefaultName = findViewById(R.id.tv_seller_name);


        ///Set Array values add array for image url
        populateMerchant(merchantAvailableList);
        populateReview(reviewDataList);

        //Image carousel set up
        carouselView = findViewById(R.id.carouselView_pd);
        carouselView.setPageCount(sampleImages.length);
        carouselView.setImageListener(imageListener);


        ///Setting Average rating get api call
        double sumRating =0;
        for (ReviewData m:reviewDataList
        ) {
            sumRating = sumRating + Double.valueOf(m.getCustomerRating());
        }
         avgRating = sumRating/reviewDataList.size();
        TextView textView =findViewById(R.id.avg_rating_pd);
        textView.setText(String.valueOf((int)avgRating)+" ⭐️");

        //Sort the Array according to lowest price
        Collections.sort(merchantAvailableList, (o1, o2) -> Integer.valueOf(o1.getMerchantPrice())-Integer.valueOf(o2.getMerchantPrice()));
        //Set default merchant and price
        tvDefaultPrice.setText("$"+merchantAvailableList.get(0).getMerchantPrice().toString());
        tvDefaultName.setText("Seller Name:" +merchantAvailableList.get(0).getMerchantName().toString());




        ///Recycler for merchant view
        RecyclerView recyclerView = findViewById(R.id.recycler_merchant_pd);
        RecycleAdapterMerchant recycleAdapterMerchant = new RecycleAdapterMerchant( ProductDetailActivity.this,merchantAvailableList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(recycleAdapterMerchant);
        //Recycler for review view
        RecyclerView recyclerView1 = findViewById(R.id.recycler_reviews_pd);
        RecycleAdapterReview recycleAdapterReview = new RecycleAdapterReview( ProductDetailActivity.this,reviewDataList);
        recyclerView1.setLayoutManager(new LinearLayoutManager(this));
        recyclerView1.setAdapter(recycleAdapterReview);



        findViewById(R.id.add_to_cart_pd).setOnClickListener(view ->
        {
            //sent to cart object with details
            //callApi to send object as cart
            Retrofit retrofit = RetrofitBuilderProduct.getInstance();
            IPostApi iPostApi = retrofit.create(IPostApi.class);
            //create an quantity selector
            Call<String> addToCart = iPostApi.addToCart(new CartAdd());// Add the cart Value
            addToCart.enqueue(new Callback<String>() {
                @Override
                public void onResponse(Call<String> call, Response<String> response) {
                    // nothing
                }

                @Override
                public void onFailure(Call<String> call, Throwable t) {

                }
            });
            Toast.makeText(getApplicationContext(),tvDefaultName.getText(),Toast.LENGTH_SHORT).show();
        });


    }

    @Override
    public void onMerchantClick(MerchantAvailable merchantAvailable) {
        //choose seller
        TextView textView =findViewById(R.id.tv_price_pd);
        TextView textView1 = findViewById(R.id.tv_seller_name);
        textView.setText("$"+merchantAvailable.getMerchantPrice().toString());
        textView1.setText("Seller Name: "+merchantAvailable.getMerchantName());
    }

    @Override
    public void onReviewClick(ReviewData reviewData) {
       //Action when user clicks on a review
    }

    ImageListener imageListener = (position, imageView) -> imageView.setImageResource(sampleImages[position]);

    public void imageClick(View view)
    {
        Log.i("TESTER", "imageClick:hi ");
    }

    public void populateMerchant(List<MerchantAvailable> merchantAvailables)
    {
        merchantAvailables.add(new MerchantAvailable("sdfds","Raja","4.5","200"));
        merchantAvailables.add(new MerchantAvailable("fsf","Abhinav","5","250"));
        merchantAvailables.add(new MerchantAvailable("dsf","Aaakash","4.5","3000"));
        merchantAvailables.add(new MerchantAvailable("sd","SHwetha","5","180"));
        merchantAvailables.add(new MerchantAvailable("dsgsd","Anirudh","4","20"));
    }
    public void populateReview(List<ReviewData> reviewData)
    {

        reviewData.add(new ReviewData("Shubham","4.5","It is very Nice and good to use"));
        reviewData.add(new ReviewData("Harish","4","Best in Range"));
        reviewData.add(new ReviewData("Manav","3","Okay product"));
        reviewData.add(new ReviewData("Rajat","5","You cant get a better offer so go grab it up"));
        reviewData.add(new ReviewData("Girish","4.5","Makes me Happy ;)"));
        reviewData.add(new ReviewData("Sonu","4","I wouldnt really care to rate but after using this for few days i really got some chiil these are reaaly Good in this raneg. "));


    }

    private void initApiReq(String productId)
    {
        Retrofit retrofit = RetrofitBuilderProduct.getInstance();
        IPostApi iPostApi = retrofit.create(IPostApi.class);

        Call<ProductData> productDetail = iPostApi.getProduct();
        Call<List<MerchantData>> merList = iPostApi.getMerchants();
        Call<Ratings> ratingsObj = iPostApi.getRatings();
       Call<Integer> totalStock =iPostApi.getTotalStock();

       productDetail.enqueue(new Callback<ProductData>() {
           @Override
           public void onResponse(Call<ProductData> call, Response<ProductData> response) {
               //Add product detail
               productName = response.body().getProductName();
               productUsp = response.body().getAttribute();


           }

           @Override
           public void onFailure(Call<ProductData> call, Throwable t) {

           }
       });


       merList.enqueue(new Callback<List<MerchantData>>() {
           @Override
           public void onResponse(Call<List<MerchantData>> call, Response<List<MerchantData>> response) {
               //Add merchant List

               List<MerchantData> list = response.body();
               int i =0;
               for (MerchantData m:list
                    ) {
                   merchantAvailableList.get(i).setMerchantId(m.getMerchantId());
                   merchantAvailableList.get(i).setMerchantPrice(String.valueOf(m.getMerchantPrice()));
                   Call<String> merchantProf = iPostApi.getMerchantById(m.getMerchantId());
                   int finalI = i;
                   merchantProf.enqueue(new Callback<String>() {
                       @Override
                       public void onResponse(Call<String> call, Response<String> response) {
                         String s=  response.body();
                           StringTokenizer st = new StringTokenizer(s,";");
                           merchantAvailableList.get(finalI).setMerchantName(st.nextToken());
                           merchantAvailableList.get(finalI).setMerchantRating(st.nextToken());
                       }

                       @Override
                       public void onFailure(Call<String> call, Throwable t) {

                       }
                   });
                   i++;
               }
           }

           @Override
           public void onFailure(Call<List<MerchantData>> call, Throwable t) {

           }
       });

       ratingsObj.enqueue(new Callback<Ratings>() {
           @Override
           public void onResponse(Call<Ratings> call, Response<Ratings> response) {
               // Set review list

               avgRating = response.body().getRating();
               List<RateItem> rateItems = response.body().getRate();
               int i=0;
               for (RateItem r: rateItems
                    ) {
                   reviewDataList.get(i).setCustomerName(r.getCustomerId());
                   reviewDataList.get(i).setCustomerRating(String.valueOf(r.getRating()));
                   reviewDataList.get(i).setCustomerReview(r.getReview());
                   i++;
               }
           }

           @Override
           public void onFailure(Call<Ratings> call, Throwable t) {

           }
       });






       totalStock.enqueue(new Callback<Integer>() {
           @Override
           public void onResponse(Call<Integer> call, Response<Integer> response) {
               stocking = response.body();
                  //Set Total Stock
           }

           @Override
           public void onFailure(Call<Integer> call, Throwable t) {

           }
       });

    }

}