package com.example.productpage.network;

import com.example.productpage.pojorepo.CartAdd;
import com.example.productpage.pojorepo.MerchantData;
import com.example.productpage.pojorepo.ProductData;
import com.example.productpage.pojorepo.Ratings;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface IPostApi {


    @GET("posts")//url to products get productBy id
    Call<ProductData> getProduct();

    @GET("merchantprofile/{merchantId}")
     Call<String> getMerchantById(@Path(value = "merchantId")String id);

     @GET("posts")//url to rating Api get by product Id
    Call<Ratings> getRatings();

     @GET("posts")// call to inventory table
    Call<List<MerchantData>> getMerchants();

     @GET("posts")//inventory table
    Call<Integer> getTotalStock();


     @PUT("jh")// url to cart table change in server required
    Call<String> addToCart(@Body CartAdd cartAdd);

}
