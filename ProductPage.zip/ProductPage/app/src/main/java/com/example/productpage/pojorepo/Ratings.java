package com.example.productpage.pojorepo;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class Ratings{

	@SerializedName("productId")
	private String productId;

	@SerializedName("rate")
	private List<RateItem> rate;

	@SerializedName("rating")
	private int rating;

	public String getProductId(){
		return productId;
	}

	public List<RateItem> getRate(){
		return rate;
	}

	public int getRating(){
		return rating;
	}
}