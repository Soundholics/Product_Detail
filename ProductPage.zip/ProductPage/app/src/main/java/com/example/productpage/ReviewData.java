package com.example.productpage;

public class ReviewData {


    private String customerId;
    private String customerName;
    private String customerRating;
    private String customerReview;

    public ReviewData(String customerId, String customerName, String customerRating, String customerReview) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerRating = customerRating;
        this.customerReview = customerReview;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerRating() {
        return customerRating;
    }

    public void setCustomerRating(String customerRating) {
        this.customerRating = customerRating;
    }

    public String getCustomerReview() {
        return customerReview;
    }

    public void setCustomerReview(String customerReview) {
        this.customerReview = customerReview;
    }
}
